#include <CashCode_CCNET_RUS.h>

CashCode_CCNET_RUS CC(9600); // baudRate of your bill validator
/* 
 *  HOW TO CONNECT YOUR BILL VALIDATOR TO YOUR ARDUINO:
 *  USE 6 PIN CONNECTOR FOR BOWER AND 18 PIN CONNECTOR FOR DATA (common ground for Arduino and Bill Validator required)
 *  [6 PIN]
 *  1 PIN - +12V  3 PIN - PULSE SIGNAL (not used)   5 PIN - INHIBIT + (not used)
 *  2 PIN - GND   4 PIN - PULSE SIGNAL (not used)   6 PIN - INHIBIT - (not used)
 *  [18 PIN]
 *  11 PIN (TXD) - PIN 0 of Arduino (RX0)
 *  16 PIN (RXD) - PIN 1 of Arduino (TX1)
 *  All options:
 *  void update(); -- put this in looped cycle. It updates your bill validator status
 *  int getBanknote(); -- returns accepted bill value. Available banknotes: 10 RUB, 50 RUB, 100 RUB (old), 200 RUB, 500 RUB, 1000 RUB, 2000 RUB, 5000 RUB (old)
 *  void disable(); -- disable bill validator (switch it's status to unavailable).
 *  void enable(); -- enable bill validator and start accepting banknotes (use reset before it).
 *  void reset(); -- reset bill validator (also helps if banknote got stuck).
 *  
 *  IMPORTANT NOTE: disconnect your Arduino from bill validator before upload!
*/
void setup() {
  CC.reset(); // reset bill validator before enabling
  CC.enable(); // enable bill validator
}

void loop() {
  CC.update(); // update status
  int bill = CC.getBanknote(); // write bill info into number value
}